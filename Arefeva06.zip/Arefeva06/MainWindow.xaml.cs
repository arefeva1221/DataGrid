﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Arefeva06
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PeopleEntities db;
        
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PeopleSet people = new PeopleSet();
            people.Surname = sur.Text;
            people.Name = name.Text;
            people.Middle_name = mid.Text;
            people.Phone = ph.Text;
            people.Address = ad.Text;
            db.PeopleSet.Add(people);
            db.SaveChanges();
            gridPeople.ItemsSource = db.PeopleSet.ToList();
            sur.Text = "";
            name.Text = "";
            mid.Text = "";
            ph.Text = "";
            ad.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int num = Convert.ToInt32(id.Text);
            var dRow = db.PeopleSet.Where(w => w.Id == num).FirstOrDefault();
            db.PeopleSet.Remove(dRow);
            db.SaveChanges();
            gridPeople.ItemsSource = db.PeopleSet.ToList();
          
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int num = Convert.ToInt32(id.Text);
            var uRow = db.PeopleSet.Where(w => w.Id == num).FirstOrDefault();
            uRow.Surname = sur.Text;
            uRow.Name = name.Text;
            uRow.Middle_name = mid.Text;
            uRow.Phone = ph.Text;
            uRow.Address = ad.Text;
            db.SaveChanges();
            gridPeople.ItemsSource = db.PeopleSet.ToList();
         
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            db = new PeopleEntities();
            gridPeople.ItemsSource = db.PeopleSet.ToList();
        }
    }
}
